# What is a training package?

This is a training package that you have downloaded on the Lumia website. It is designed to help you build your own AI by communicating with a game server using image inputs. You are given only the essential communication logic — **you must write your own AI**.

---

## What's in this package?

- **`starter_script.py`**: The script that connects to the game server, receives image data, and sends predictions. The AI logic is left almost empty for you to write.
- **The game file**: A script named like `SnakeGame.py` or similar. Run this first.
- **A placeholder opponent**: This AI always plays first and must be started before yours.
- **Gameselect of 20 imgages**: Use it to debug you'r AI
- **ImageRecognition-manual**: Helpful to understant the logic of the game what you AI need to respond to the game can be use without an IA just launch the game before and enter the prediction by yourself 

## Who it's work ?

---

# Prediction (Client Mode):
  python cnn_training_package.py

# Prediction (Client Mode):

  python cnn_training_package.py --train --dataset path_to_your_dataset