import socket
import json
from PIL import Image
from torchvision import transforms

transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
])

# This is where students will write their decision-making logic
def ia_decision(image_path):
    # ========== STUDENT ZONE ==========
    # image = Image.open(image_path).convert('RGB')
    # image_tensor = transform(image).unsqueeze(0)
    #
    # Write your prediction logic here
    # Example: return your_model.predict(image_tensor)
    #
    # TEMPORARY: ask for manual input
    print(f"\nImage received: {image_path}")
    return input("Enter your prediction (0 or 1): ")
    # ==================================

def run_client():
    HOST = '127.0.0.1'
    PORT = 5001

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Client connected to game server.\n")

        while True:
            data = s.recv(1024).decode()
            if not data:
                print("[DISCONNECTED]")
                break

            try:
                game_data = json.loads(data)
                image_path = game_data.get("imagePath", "")
            except json.JSONDecodeError:
                print("[!] Invalid JSON data received.")
                continue

            prediction = ia_decision(image_path)

            if not prediction:
                prediction = "0"  # Default fallback
                print("[!] No prediction made. Sent default: 0")

            print(f"Prediction sent: {prediction}")
            s.sendall(prediction.encode())

if __name__ == "__main__":
    run_client()
